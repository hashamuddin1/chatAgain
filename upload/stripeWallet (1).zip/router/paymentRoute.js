const express = require("express");
const paymentRouter = express.Router();
const {
  insertPayment,
  getAllPayment,
  succeededPayment,
  withDrawPayment,
  sendPaymentToOthers,
} = require("../controller/paymentController");
const verifyToken = require("../middleware/verifyToken");

paymentRouter.post("/api/v1/insertPayment", [verifyToken], insertPayment);
paymentRouter.get("/api/v1/getAllPayment", [verifyToken], getAllPayment);
paymentRouter.post("/api/v1/succeededPayment", [verifyToken], succeededPayment);
paymentRouter.post("/api/v1/withDrawPayment", [verifyToken], withDrawPayment);
paymentRouter.post(
  "/api/v1/sendPaymentToOthers",
  [verifyToken],
  sendPaymentToOthers
);

module.exports = paymentRouter;
