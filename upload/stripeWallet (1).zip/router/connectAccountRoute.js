const express = require("express");
const connectAccountRouter = express.Router();
const {
  createStripeAccount,
} = require("../controller/connectAccountController");
const verifyToken = require("../middleware/verifyToken");

connectAccountRouter.post(
  "/api/v1/createStripeAccount",
  [verifyToken],
  createStripeAccount
);

module.exports = connectAccountRouter;
