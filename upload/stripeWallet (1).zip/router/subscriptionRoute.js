const express = require("express");
const subscriptionRouter = express.Router();
const {
  buySubscription,
  confirmSubscription,
} = require("../controller/subscriptionController");
const verifyToken = require("../middleware/verifyToken");

subscriptionRouter.post(
  "/api/v1/buySubscription",
  [verifyToken],
  buySubscription
);

subscriptionRouter.post(
  "/api/v1/confirmSubscription",
  [verifyToken],
  confirmSubscription
);

module.exports = subscriptionRouter;
