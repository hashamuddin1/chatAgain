const express = require("express");
const walletRouter = express.Router();
const {
  connectWallet,
  fetchWallet,
} = require("../controller/walletController");
const verifyToken = require("../middleware/verifyToken");

walletRouter.post("/api/v1/connectWallet", [verifyToken], connectWallet);
walletRouter.get("/api/v1/fetchWallet", [verifyToken], fetchWallet);

module.exports = walletRouter;
