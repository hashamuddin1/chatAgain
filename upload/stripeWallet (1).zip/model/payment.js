const mongoose = require("mongoose");

const payment_schema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "users",
    },
    amount: {
      type: Number,
      required: false,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

const payment = new mongoose.model("payment", payment_schema);

module.exports = { payment };
