const mongoose = require("mongoose");

const subscription_schema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "users",
    },
    type: {
      type: String,
      enum: ["freeTrial", "monthly", "yearly"],
    },
    productId: {
      type: String,
      required: true,
    },
    subscriptionId: {
      type: String,
      required: true,
    },
    isExpire: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

const subscription = new mongoose.model("subscription", subscription_schema);

module.exports = { subscription };
