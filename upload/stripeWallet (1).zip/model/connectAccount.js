const mongoose = require("mongoose");

const account_schema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "users",
    },
    connectAccountId: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const connectedAccount = new mongoose.model("connectedAccount", account_schema);

module.exports = { connectedAccount };
