const mongoose = require("mongoose");

const wallet_schema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "auth",
    },
    customerId: {
      type: String,
      required: true,
      trim: true,
    },
    amount: {
      type: Number,
      required: false,
      default: 0,
    },
    paymentMethodId: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

const wallet = new mongoose.model("wallet", wallet_schema);

module.exports = { wallet };
