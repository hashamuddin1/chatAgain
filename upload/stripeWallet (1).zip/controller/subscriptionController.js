const { wallet } = require("../model/wallet");
const { subscription } = require("../model/subscription");
const PROCESS = process.env;
const stripe = require("stripe")(PROCESS.STRIPE_SECRET_KEY);

const buySubscription = async (req, res) => {
  try {
    const fetchWallet = await wallet.findOne({ userId: req.user._id });
    if (req.body.subscriptionType === "freeTrial") {
      const stripeSubscription = await stripe.subscriptions.create({
        customer: fetchWallet.customerId,
        items: [
          {
            price: PROCESS.freeTrialPriceID,
          },
        ],
        metadata: { type: "freeTrial" },

        trial_period_days: 14,
        payment_settings: {
          payment_method_types: ["card"],
          save_default_payment_method: "on_subscription",
        },
        trial_settings: {
          end_behavior: {
            missing_payment_method: "cancel",
          },
        },
      });

      const fetchSubscription = await subscription.findOne({
        userId: req.user._id,
      });
      if (!fetchSubscription) {
        const newSubscription = new subscription({
          userId: req.user._id,
          type: req.body.subscriptionType,
          productId: PROCESS.freeTrialProductID,
          subscriptionId: stripeSubscription.id,
        });

        await newSubscription.save();
      } else {
        await subscription.updateOne(
          { userId: req.user._id },
          {
            type: req.body.subscriptionType,
            productId: PROCESS.freeTrialProductID,
            subscriptionId: stripeSubscription.id,
            isExpire: false,
          }
        );
      }

      return res.status(200).send({
        success: true,
        message: `${req.body.subscriptionType} Subscription has been created of a User`,
      });
    } else if (req.body.subscriptionType === "monthly") {
      if (fetchWallet.amount < 10) {
        return res.status(400).send({
          success: false,
          message: `You donot have much amount to buy ${req.body.subscriptionType} Subscription`,
        });
      }
      const stripeSubscription = await stripe.subscriptions.create({
        customer: fetchWallet.customerId,
        items: [{ price: PROCESS.monthlyPriceID }],
        payment_settings: {
          payment_method_options: {
            card: {
              request_three_d_secure: "automatic",
            },
          },
          payment_method_types: ["card"],
          save_default_payment_method: "on_subscription",
        },
        trial_settings: {
          end_behavior: {
            missing_payment_method: "create_invoice",
          },
        },
        expand: ["latest_invoice.payment_intent"],
        metadata: { type: "monthly" },
      });

      if (stripeSubscription.status === "active") {
        await wallet.updateOne(
          {
            userId: req.user._id,
          },
          { $inc: { amount: -10 } }
        );
        const fetchSubscription = await subscription.findOne({
          userId: req.user._id,
        });
        if (!fetchSubscription) {
          const newSubscription = new subscription({
            userId: req.user._id,
            type: req.body.subscriptionType,
            productId: PROCESS.monthlyProductID,
            subscriptionId: stripeSubscription.id,
          });

          await newSubscription.save();
        } else {
          await subscription.updateOne(
            { userId: req.user._id },
            {
              type: req.body.subscriptionType,
              productId: PROCESS.monthlyProductID,
              subscriptionId: stripeSubscription.id,
              isExpire: false,
            }
          );
        }
      } else {
        return res.status(200).send({
          success: true,
          message: `${req.body.subscriptionType} Subscription has been created of a User But not Active`,
          data: {
            subscriptionId: stripeSubscription.id,
            clientSecret:
              stripeSubscription.latest_invoice.payment_intent.client_secret,
            productId: PROCESS.monthlyProductID,
            customerId: fetchWallet.customerId,
            type: req.body.subscriptionType,
            amount: 10,
          },
        });
      }

      return res.status(200).send({
        success: true,
        message: `${req.body.subscriptionType} Subscription has been created of a User`,
      });
    } else if (req.body.subscriptionType === "yearly") {
      if (fetchWallet.amount < 100) {
        return res.status(400).send({
          success: false,
          message: `You donot have much amount to buy ${req.body.subscriptionType} Subscription`,
        });
      }

      const stripeSubscription = await stripe.subscriptions.create({
        customer: fetchWallet.customerId,
        items: [{ price: PROCESS.yearlyPriceID }],
        payment_settings: {
          payment_method_options: {
            card: {
              request_three_d_secure: "automatic",
            },
          },
          payment_method_types: ["card"],
          save_default_payment_method: "on_subscription",
        },
        trial_settings: {
          end_behavior: {
            missing_payment_method: "create_invoice",
          },
        },
        expand: ["latest_invoice.payment_intent"],
        metadata: { type: "yearly" },
      });

      if (stripeSubscription.status === "active") {
        await wallet.updateOne(
          {
            userId: req.user._id,
          },
          { $inc: { amount: -100 } }
        );
        const fetchSubscription = await subscription.findOne({
          userId: req.user._id,
        });
        if (!fetchSubscription) {
          const newSubscription = new subscription({
            userId: req.user._id,
            type: req.body.subscriptionType,
            productId: PROCESS.yearlyProductID,
            subscriptionId: stripeSubscription.id,
          });

          await newSubscription.save();
        } else {
          await subscription.updateOne(
            { userId: req.user._id },
            {
              type: req.body.subscriptionType,
              productId: PROCESS.yearlyProductID,
              subscriptionId: stripeSubscription.id,
              isExpire: false,
            }
          );
        }
      } else {
        return res.status(200).send({
          success: true,
          message: `${req.body.subscriptionType} Subscription has been created of a User But not Active`,
          data: {
            subscriptionId: stripeSubscription.id,
            clientSecret:
              stripeSubscription.latest_invoice.payment_intent.client_secret,
            productId: PROCESS.yearlyProductID,
            customerId: fetchWallet.customerId,
            type: req.body.subscriptionType,
            amount: 100,
          },
        });
      }

      return res.status(200).send({
        success: true,
        message: `${req.body.subscriptionType} Subscription has been created of a User`,
      });
    }
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

const confirmSubscription = async (req, res) => {
  try {
    await wallet.updateOne(
      {
        userId: req.user._id,
      },
      { $inc: { amount: -req.body.amount } }
    );
    const fetchSubscription = await subscription.findOne({
      userId: req.user._id,
    });

    if (!fetchSubscription) {
      const newSubscription = new subscription({
        userId: req.user._id,
        type: req.body.subscriptionType,
        productId: req.body.productID,
        subscriptionId: req.body.subscriptionID,
      });

      await newSubscription.save();

      return res.status(200).send({
        success: true,
        message: `${req.body.subscriptionType} Subscription has been confirm of a User`,
      });
    } else {
      await subscription.updateOne(
        { userId: req.user._id },
        {
          type: req.body.subscriptionType,
          productId: req.body.productID,
          subscriptionId: req.body.subscriptionID,
          isExpire: false,
        }
      );

      return res.status(200).send({
        success: true,
        message: `${req.body.subscriptionType} Subscription has been confirm of a User`,
      });
    }
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

module.exports = {
  buySubscription,
  confirmSubscription,
};
