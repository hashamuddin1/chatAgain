const { wallet } = require("../model/wallet");
const PROCESS = process.env;
const stripe = require("stripe")(PROCESS.STRIPE_SECRET_KEY);

const connectWallet = async (req, res) => {
  try {
    const fetchWallet = await wallet.findOne({ userId: req.user._id });
    if (fetchWallet) {
      return res.status(200).send({
        success: false,
        message: "Wallet has already been connected of this User",
      });
    }
    const customer = await stripe.customers.create({
      name: req.user.first_name,
      email: req.user.email,
      payment_method: req.body.stripePaymentMethodId,
      invoice_settings: {
        default_payment_method: req.body.stripePaymentMethodId,
      },
    });

    const insertWallet = new wallet({
      userId: req.user._id,
      customerId: customer.id,
      paymentMethodId: req.body.stripePaymentMethodId,
    });

    await insertWallet.save();

    return res.status(200).send({
      success: true,
      message: "Wallet has been connected of a User",
      data: insertWallet,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

const fetchWallet = async (req, res) => {
  try {
    const getWallet = await wallet.findOne({ userId: req.user._id });
    return res.status(200).send({
      success: false,
      message: "Wallet has been Fetched of a User",
      data: getWallet,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

module.exports = { connectWallet, fetchWallet };
