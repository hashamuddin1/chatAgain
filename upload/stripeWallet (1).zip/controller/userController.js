const { users } = require("../model/user");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const userSignUp = async (req, res) => {
  try {
    const checkEmail = await users.findOne({ email: req.body.email });
    if (checkEmail) {
      return res.status(400).send({
        success: false,
        message: "This Email is already Exist",
      });
    }
    const adduser = new users({
      first_name: req.body.first_name,
      last_name: req.body.last_name,
      email: req.body.email,
      password: req.body.password,
    });
    const encryptedPassword = await bcrypt.hash(adduser.password, 10);
    adduser.password = encryptedPassword;
    await adduser.save();
    const token = jwt.sign(
      {
        _id: adduser._id,
        email: adduser.email,
        first_name: adduser.first_name,
        last_name: adduser.last_name,
      },
      process.env.TOKEN_KEY,
      {
        expiresIn: "3d",
      }
    );
    return res.send({
      status: 200,
      message: "User has been created",
      data: adduser,
      token,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

const userLogin = async (req, res) => {
  try {
    const checkEmail = await users.findOne({ email: req.body.email });
    if (!checkEmail) {
      return res.status(400).send({
        success: false,
        message: "Invalid Email",
      });
    }

    if (
      checkEmail &&
      (await bcrypt.compare(req.body.password, checkEmail.password))
    ) {
      const token = jwt.sign(
        {
          email: checkEmail.email,
          _id: checkEmail._id,
          first_name: checkEmail.first_name,
          last_name: checkEmail.last_name,
        },
        process.env.TOKEN_KEY,
        {
          expiresIn: "3d",
        }
      );

      return res.status(200).send({
        success: true,
        message: "User Login Successfully",
        data: checkEmail,
        token,
      });
    } else {
      return res.status(400).send({
        success: false,
        message: "Invalid Credentials",
      });
    }
  } catch (e) {
    console.log(e);
    res.status(400).send(e);
  }
};

module.exports = { userSignUp, userLogin };
