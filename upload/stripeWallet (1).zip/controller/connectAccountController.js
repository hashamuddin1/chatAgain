const PROCESS = process.env;
const stripe = require("stripe")(PROCESS.STRIPE_SECRET_KEY);
const { connectedAccount } = require("../model/connectAccount");

const createStripeAccount = async (req, res) => {
  try {
    const fetchAccount = await connectedAccount.findOne({
      userId: req.user._id,
    });
    if (fetchAccount) {
      return res.status(400).send({
        success: false,
        message: "You have Already Created an Account",
      });
    }
    let account;
    if (req.body.country === "US") {
      account = await stripe.accounts.create({
        type: "custom",
        country: req.body.country,
        email: req.user.email,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_profile: {
          mcc: req.body.mcc,
          name: req.body.businessName,
          support_email: req.body.supportEmail,
          support_phone: req.body.businessPhone,
          support_url: req.body.supportUrl,
          url: req.body.supportUrl,
          support_address: {
            country: req.body.country,
            city: req.body.city,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.PostalCode,
            state: req.body.state,
          },
        },
        business_type: "individual",
        company: {
          tax_id: req.body.taxId,
          name: req.body.businessName,
          phone: req.body.businessPhone,
          address: {
            city: req.body.city,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.PostalCode,
            state: req.body.state,
          },
        },
        individual: {
          address: {
            city: req.body.city,
            state: req.body.state,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.PostalCode,
          },
          ssn_last_4: req.body.ssnLast4Digit,
          id_number: req.body.idNumber,
          verification: {
            additional_document: {
              front: "file_identity_document_success",
            },
            document: {
              front: "file_identity_document_success",
            },
          },
          dob: {
            day: req.body.day,
            month: req.body.month,
            year: req.body.year,
          },
          email: req.user.email,
          first_name: req.user.first_name,
          last_name: req.user.last_name,
          maiden_name: req.body.maidenName,
          phone: req.body.businessPhone,
          registered_address: {
            city: req.body.city,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.Postal_code,
          },
        },
        external_account: {
          account_number: req.body.accountNumber,
          object: "bank_account",
          country: req.body.country,
          currency: req.body.accountCurrency,
          routing_number: req.body.routingNumber,
        },

        tos_acceptance: {
          date: Math.floor(Date.now() / 1000),
          ip: req.connection.remoteAddress,
        },
      });
    } else {
      account = await stripe.accounts.create({
        type: "custom",
        country: req.body.country,
        email: req.user.email,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_profile: {
          mcc: req.body.mcc,
          name: req.body.businessName,
          support_email: req.body.supportEmail,
          support_phone: req.body.businessPhone,
          support_url: req.body.supportUrl,
          url: req.body.supportUrl,
          support_address: {
            country: req.body.country,
            city: req.body.city,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.PostalCode,
            state: req.body.state,
          },
        },
        business_type: "individual",
        company: {
          tax_id: req.body.taxId,
          name: req.body.businessName,
          phone: req.body.businessPhone,
          address: {
            city: req.body.city,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.PostalCode,
            state: req.body.state,
          },
        },
        individual: {
          address: {
            city: req.body.city,
            state: req.body.state,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.PostalCode,
          },
          id_number: req.body.idNumber,
          verification: {
            additional_document: {
              front: "file_identity_document_success",
            },
            document: {
              front: "file_identity_document_success",
            },
          },
          dob: {
            day: req.body.day,
            month: req.body.month,
            year: req.body.year,
          },
          email: req.user.email,
          first_name: req.user.first_name,
          last_name: req.user.last_name,
          maiden_name: req.body.maidenName,
          phone: req.body.businessPhone,
          registered_address: {
            city: req.body.city,
            line1: req.body.AddressOne,
            line2: req.body.AddressTwo,
            postal_code: req.body.Postal_code,
          },
        },
        external_account: {
          account_number: req.body.accountNumber,
          object: "bank_account",
          country: req.body.country,
          currency: req.body.accountCurrency,
          routing_number: req.body.routingNumber,
        },

        tos_acceptance: {
          date: Math.floor(Date.now() / 1000),
          ip: req.connection.remoteAddress,
        },
      });
    }

    const insertAccount = new connectedAccount({
      userId: req.user._id,
      connectAccountId: account.id,
    });

    await insertAccount.save();

    return res.status(200).send({
      success: true,
      message: "Stripe Connect Account has been created",
      data: account,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

module.exports = { createStripeAccount };
