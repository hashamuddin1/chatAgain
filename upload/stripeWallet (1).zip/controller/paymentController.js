const { payment } = require("../model/payment");
const { wallet } = require("../model/wallet");
const { users } = require("../model/user");
const { connectedAccount } = require("../model/connectAccount");
const PROCESS = process.env;
const stripe = require("stripe")(PROCESS.STRIPE_SECRET_KEY);

const insertPayment = async (req, res) => {
  try {
    const fetchUser = await wallet.findOne({ userId: req.user._id });

    if (!fetchUser) {
      return res.status(400).send({
        success: false,
        message: "You Do not have Wallet",
      });
    }
    const createPaymentIntent = await stripe.paymentIntents.create({
      amount: req.body.amount * 100,
      currency: "usd",
      automatic_payment_methods: { enabled: true },
      customer: fetchUser.customerId,
      payment_method: fetchUser.paymentMethodId,
    });

    if (createPaymentIntent.status === "succeeded") {
      const newPayment = new payment({
        userId: req.user._id,
        amount: req.body.amount,
      });

      await newPayment.save();

      await wallet.updateOne(
        {
          userId: req.user._id,
        },
        { $inc: { amount: req.body.amount } }
      );

      return res.status(200).send({
        success: true,
        message: "Payment has been created of a User",
        data: newPayment,
      });
    } else {
      return res.status(200).send({
        success: true,
        message: "Payment has been created But Not Succeeded",
        client_secret: createPaymentIntent.client_secret,
      });
    }
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

const getAllPayment = async (req, res) => {
  try {
    const fetchPayment = await payment.find({ userId: req.user._id });
    return res.status(200).send({
      success: true,
      message: "All Payment has been fetched of a User",
      data: fetchPayment,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

const succeededPayment = async (req, res) => {
  try {
    const newPayment = new payment({
      userId: req.user._id,
      amount: req.body.amount,
    });

    await newPayment.save();

    await wallet.updateOne(
      {
        userId: req.user._id,
      },
      { $inc: { amount: req.body.amount } }
    );

    return res.status(200).send({
      success: true,
      message: "Payment has been created of a User",
      data: newPayment,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

const withDrawPayment = async (req, res) => {
  try {
    const fetchAccount = await connectedAccount.findOne({
      userId: req.user._id,
    });
    if (!fetchAccount) {
      return res.status(400).send({
        success: false,
        message: "You Do not have Stripe Account",
      });
    }
    const fetchWallet = await wallet.findOne({ userId: req.user._id });
    if (!fetchWallet) {
      return res.status(400).send({
        success: false,
        message: "You Do not have Wallet",
      });
    }

    if (fetchWallet.amount < req.body.amount) {
      return res.status(400).send({
        success: false,
        message: `You Do not have Much Amount. Your current balance is ${fetchWallet.amount}`,
      });
    }
    const transfer = await stripe.transfers.create({
      amount: req.body.amount * 100,
      currency: "usd",
      destination: fetchAccount.connectAccountId,
    });

    await wallet.updateOne(
      {
        userId: req.user._id,
      },
      { $inc: { amount: -req.body.amount } }
    );

    return res.status(200).send({
      success: true,
      message: "Payment has been Withdraw by a User",
      data: transfer,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

const sendPaymentToOthers = async (req, res) => {
  try {
    const fetchWallet = await wallet.findOne({ userId: req.user._id });
    if (!fetchWallet) {
      return res.status(400).send({
        success: false,
        message: "You Do not have Wallet",
      });
    }

    if (fetchWallet.amount === 0) {
      return res.status(400).send({
        success: false,
        message: "You Do not have Amount in your Wallet",
      });
    }

    if (fetchWallet.amount < req.body.amount) {
      return res.status(400).send({
        success: false,
        message: `You Do not have Much Amount. Your current balance is ${fetchWallet.amount}`,
      });
    }
    const fetchUser = await users.findOne({
      _id: req.body.userId,
    });
    if (!fetchUser) {
      return res.status(400).send({
        success: false,
        message: "Receiver Not Found Of This ID",
      });
    }

    const fetchAccount = await connectedAccount.findOne({
      userId: req.body.userId,
    });

    if (!fetchAccount) {
      return res.status(400).send({
        success: false,
        message: "Receiver Do not have Account",
      });
    }

    const transfer = await stripe.transfers.create({
      amount: req.body.amount * 100,
      currency: "usd",
      destination: fetchAccount.connectAccountId,
    });

    await wallet.updateOne(
      {
        userId: req.user._id,
      },
      { $inc: { amount: -req.body.amount } }
    );

    const newPayment = new payment({
      userId: req.user._id,
      amount: req.body.amount,
    });

    await newPayment.save();

    await wallet.updateOne(
      {
        userId: req.body.userId,
      },
      { $inc: { amount: req.body.amount } }
    );

    return res.status(200).send({
      success: true,
      message: "Payment has been transfer to a User",
      data: transfer,
    });
  } catch (e) {
    console.log(e);
    return res.status(400).send(e);
  }
};

module.exports = {
  insertPayment,
  getAllPayment,
  succeededPayment,
  withDrawPayment,
  sendPaymentToOthers,
};
