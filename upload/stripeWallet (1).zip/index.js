const express = require("express");
const app = express();
require("dotenv").config();
const port = process.env.PORT;

require("./config/database");
const userRouter = require("./router/userRoute");
const walletRouter = require("./router/walletRoute");
const paymentRouter = require("./router/paymentRoute");
const connectAccountRouter = require("./router/connectAccountRoute");
const subscriptionRouter = require("./router/subscriptionRoute");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use([
  userRouter,
  walletRouter,
  paymentRouter,
  connectAccountRouter,
  subscriptionRouter,
]);

app.listen(port, () => {
  console.log(`Our Server is running at port ${port}`);
});
